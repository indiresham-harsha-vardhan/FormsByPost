from django.shortcuts import render,redirect,get_object_or_404
from .models import Product,Cart
# Create your views here.
def home(request):
    sunglasses = Product.objects.filter(category='Sunglasses')  # Fetch Sunglasses
    eyeglasses = Product.objects.filter(category='Eyeglasses')  # Fetch Eyeglasses
    return render(request, 'home.html', {'sunglasses': sunglasses, 'eyeglasses': eyeglasses})

def sunglass(request):
    products = Product.objects.filter(category='Sunglasses')
    return render(request,'sunglass.html',{'products': products})

def eyeglassess(request):
    products =  Product.objects.filter(category='Eyeglasses')
    return render(request,'eyeglassess.html', {'products': products})

def termsandconditions(request):
    return render(request,'termsandconditions.html')

def contact(request):
    return render(request,'contact.html')

def product_detail(request, id):
    product = Product.objects.get(id=id)
    return render(request, 'product_detail.html', {'product': product})

def view(request,id):
    products = Product.objects.get(id=id) 
    return render(request,'view_card.html',{'products': products})

def view_cart(request, id):
    cart_items = Cart.objects.filter(user_id=id) 
    print(cart_items) # Fetch all cart items for the user
    return render(request, 'cart.html', {'cart_items': cart_items})



def delete(request, id):
    cart_item = get_object_or_404(Cart, id=id)
    cart_item.delete()  # Remove only from the cart

    return redirect('app1:view_cart', id=cart_item.user_id)  # Redirect to home if no products remain


def womenglasses(request):
    return render(request,'womenglasses.html')

def menglasses(request):
    return render(request,'menglasses.html')
def add_to_cart(request, id):
    product = get_object_or_404(Product, id=id)
    user_id = request.user.id if request.user.is_authenticated else 1  # Replace 1 with session user ID if needed

    # Check if item already exists in the cart
    cart_item, created = Cart.objects.get_or_create(product=product, user_id=user_id)

    if created:
        print(f"✅ {product.name} added to cart for user {user_id}")
    else:
        print(f"⚠️ {product.name} is already in the cart for user {user_id}")

    return redirect('app1:view_cart', id=user_id)  # Redirect to cart page
